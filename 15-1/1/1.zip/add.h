#ifndef __ADD_H__
#define __ADD_H__

int add(int lhs, int rhs);

#endif