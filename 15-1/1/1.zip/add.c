#include "add.h"

int add(int lhs, int rhs)
{
    return lhs + rhs;
}