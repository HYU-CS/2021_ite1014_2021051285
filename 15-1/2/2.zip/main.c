#include <stdio.h>
#include "point.h"
#include "pointmath.h"

int main(void)
{
    Point p1;
    Point p2;

    scanf("%d%d", &p1.xpos, &p1.ypos);

    p2 = getScale2xPoint(&p1);

    printf("%d %d\n", p2.xpos, p2.ypos);

    return 0;
}