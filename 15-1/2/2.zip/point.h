#ifndef __POINT_H__
#define __POINT_H__

typedef struct
{
    int xpos;
    int ypos;
} Point;

#endif