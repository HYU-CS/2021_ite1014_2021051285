#include "pointmath.h"

Point getScale2xPoint(const Point *p)
{
    Point temp = {p->xpos * 2, p->ypos *2};
    return temp;
}