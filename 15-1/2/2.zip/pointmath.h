#ifndef __POINTMATH_H__
#define __POINTMATH_H__

#include "point.h"

Point getScale2xPoint(const Point *p);

#endif